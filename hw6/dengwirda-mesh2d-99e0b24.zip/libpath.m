function libpath
%LIBPATH -- deprecated helper func. -- call INITMSH instead.

    initmsh() ;

end



